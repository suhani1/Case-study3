package com.tweetApp.FSE.Repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.tweetApp.FSE.Model.Tweet;

@Repository
public class TweetRepository {
	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void save(Tweet tweet) {
		dynamoDBMapper.save(tweet);
	}

	public List<Tweet> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<Tweet> result = dynamoDBMapper.scan(Tweet.class, scanner);
		return result;
	}

	public List<Tweet> findByEmail(String email) {
		HashMap<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
		eav.put(email, new AttributeValue().withS(email));
		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
				.withFilterExpression("begins_with(email,:v1)").withExpressionAttributeValues(eav);
		List<Tweet> result = dynamoDBMapper.scan(Tweet.class, scanExpression);

		return result;
	}

	public void deleteById(int id) {
		Tweet tweet = dynamoDBMapper.load(Tweet.class, id);
		dynamoDBMapper.delete(tweet);
	}
}
