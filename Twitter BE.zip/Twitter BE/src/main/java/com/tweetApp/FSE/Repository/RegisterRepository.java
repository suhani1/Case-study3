package com.tweetApp.FSE.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetApp.FSE.Model.Register;

@Repository
public class RegisterRepository {
	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public void save(Register user) {
		dynamoDBMapper.save(user);
	}

	public Register findByEmail(String email) {
		return dynamoDBMapper.load(Register.class, email);
	}

	public List<Register> findAll() {
		DynamoDBScanExpression scanner = new DynamoDBScanExpression();
		List<Register> result = dynamoDBMapper.scan(Register.class, scanner);
		return result;
	}
}
