package com.tweetApp.FSE.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.FSE.DTO.TweetRequestDTO;
import com.tweetApp.FSE.Model.Reply;
import com.tweetApp.FSE.Model.Tweet;
import com.tweetApp.FSE.Repository.ReplyRepository;
import com.tweetApp.FSE.Repository.TweetRepository;
import com.tweetApp.FSE.Repository.UserRepository;

@Service
public class TweetService {
	
	@Autowired TweetRepository tweetRepo;
	
	@Autowired UserRepository userRepo;
	
	@Autowired ReplyRepository replyRepo;
	
	public String postTweet(TweetRequestDTO tweetRequest) {
		List<Tweet> list = tweetRepo.findAll();
		int count = list.size() +1;
		Tweet tweet = new Tweet();
		tweet.setId(count);
		tweet.setEmail(tweetRequest.getEmailId());
		tweet.setRecordActive('Y');
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		tweet.setDate(dtf.format(now));
		tweet.setTweetDescription(tweetRequest.getTweetDesc());
		tweetRepo.save(tweet);
		return "SUCCESS";
	}

	public List<Tweet> getAllTweets() {
		List<Tweet> tweetList = tweetRepo.findAll();
		List<Reply> list = replyRepo.findAll();
		for(int index = 0; index < tweetList.size(); index ++) {
			List<Reply> reply = new ArrayList<>();
			for(int i = 0; i< list.size(); i++) {
				if(list.get(i).getTweetId() == tweetList.get(index).getId()) {
					reply.add(list.get(i));
				}
			}
			tweetList.get(index).setReply(reply);
		}
		return tweetList;

	}

    public boolean postReply(Reply reply) {
    	List<Reply> list = replyRepo.findAll();
		int count = list.size() + 1;
		reply.setId(count);
		replyRepo.save(reply);
		return true;
    }
    public boolean deleteTweet(int tweetId) {
    	tweetRepo.deleteById(tweetId);
    	List<Reply> list = replyRepo.findAll();
    	for(int index = 0; index < list.size(); index ++) {
    		if(list.get(index).getTweetId() == tweetId) {
    			replyRepo.deleteById(list.get(index).getId());
    		}
    	}
    	return true;
    }

}
